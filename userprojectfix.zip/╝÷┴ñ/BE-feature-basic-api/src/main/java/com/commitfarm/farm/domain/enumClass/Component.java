package com.commitfarm.farm.domain.enumClass;

public enum Component {
    UIComponent, DataAccessComponent, SecurityComponent
}