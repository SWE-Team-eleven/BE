package com.commitfarm.farm.domain.enumClass;

public enum Status {
    New, Assigned, Reopened,Resolved,Closed
}
