package com.commitfarm.farm.domain.enumClass;

public enum UserType {
    ProjectLeader, Developer, Tester
}
