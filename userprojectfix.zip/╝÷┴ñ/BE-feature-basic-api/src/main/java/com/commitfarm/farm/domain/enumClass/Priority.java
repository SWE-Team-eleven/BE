package com.commitfarm.farm.domain.enumClass;

public enum Priority {
    Blocker, Critical, Major, Minor, Trivial
    //우선순위: blocker/critical/major/minor/trivial (기본값은 major)
}