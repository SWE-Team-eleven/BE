package com.commitfarm.farm.repository;

public class TicketRepository {
}
