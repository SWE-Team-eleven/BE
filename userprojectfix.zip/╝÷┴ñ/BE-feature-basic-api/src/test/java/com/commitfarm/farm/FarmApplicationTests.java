package com.commitfarm.farm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmApplicationTests {

	@Test
	void contextLoads() {
	}

}
